﻿////has a relation/Association

//using System;
//using System.Collections.Generic;
//using System.Net.Sockets;
//class Customer
//{
//    public int customerID { get; set; }
//    public string firstName { get; set; }
//    public string lastName { get; set; }
//    public string Emailaddress { get; set; }


//    public string phoneNumber { get; set; }
//    public string address { get; set; }

//    public Customer()
//    {
//        Console.WriteLine("This is a customer class");
//    }
//    public Customer(int c, string first, string last, string email, string no, string add)
//    {
//        this.customerID = c;
//        this.firstName = first;
//        this.lastName = last;
//        this.Emailaddress = email;

//        this.address = add;

//        //validation of phone no

//        if (no.Length == 10)
//        {
//            bool isvalid = true;
//            foreach (char ch in no)
//            {
//                if (!char.IsDigit(ch))
//                {
//                    isvalid = false;
//                    break;
//                }
//            }
//            if (isvalid)
//            {
//                this.phoneNumber = no;
//            }
//            else
//            {
//                Console.WriteLine("Your number must contain only digits");
//                this.phoneNumber = "not provided";
//            }
//        }
//        else
//        {
//            Console.WriteLine("Your number must contain 10 digits");
//        }

//        //validation of emailid
//        if (!string.IsNullOrEmpty(email) && email.Contains("@") && email.
//            Contains("."))
//        {
//            this.Emailaddress = email;
//        }
//        else
//        {
//            Console.WriteLine("Enter a valid email address");
//            this.Emailaddress = "not provided";
//        }


//    }

//    public void Printcustomer()
//    {
//        Console.WriteLine("CustomerId=" + customerID);
//        Console.WriteLine("frstname=" + firstName);
//        Console.WriteLine("lastname=" + lastName);
//        Console.WriteLine("Email addresss=" + Emailaddress);
//        Console.WriteLine("Phone number=" + phoneNumber);
//        Console.WriteLine("Address=" + address);

//    }
//}

//class Account
//{
//    public long accountno { get; set; }
//    public string accounttype { get; set; }
//    public float accountbal { get; set; }
//    public Customer accountholder { get; set; }

//    public Account()
//    {
//        Console.WriteLine("This is the default constructor");
//    }
//    public Account(long accno, string acctype, float bal, Customer customer)
//    {
//        this.accountno = accno;
//        this.accounttype = acctype;
//        this.accountbal = bal;
//        this.accountholder = customer;
//    }

//    public void Display()
//    {
//        Console.WriteLine("Account number=" + accountno);
//        Console.WriteLine("Account type=" + accounttype);
//        Console.WriteLine("AccountBalance=" + accountbal);
//        Console.WriteLine("Customer details:");
//        accountholder.Printcustomer();
//    }
//}

//class Bank
//{

//    List<Account> accounts = new List<Account>();
//    static long nextaccno = 1001;
//    public void create_account(Customer customer,string acctype,float balance)
//    {
//        Account acc = new Account(nextaccno,acctype,balance,customer);
//        accounts.Add(acc);
//        Console.WriteLine("Account created successfully");
//        Console.WriteLine("Account number="+nextaccno);
//        nextaccno++;

//    }

//    public float Get_account_balance(long accno)
//    {
//        foreach (Account acc in accounts)
//        {
//            if (acc.accountno == accno)
//            {
//                return acc.accountbal;
//            }
//        }
//            Console.WriteLine("Account not found");
//            return 0;
//    }

//    public float Deposit(long accno,float amount)
//    {
//        foreach(Account acc in accounts)
//        {
//            if(acc.accountno == accno)
//            {
//                acc.accountbal=acc.accountbal+amount;
//                Console.WriteLine("Deposit succesful");
//                return acc.accountbal;
//            }
//        }Console.WriteLine("Account not found");
//        return 0;
//    }

//    public float Withdraw(long accno,float amount)
//    {
//        foreach( Account acc in accounts)
//        {
//            if( acc.accountbal == accno)
//            {
//                if (acc.accountbal >= amount)
//                {
//                    acc.accountbal = acc.accountbal-amount;
//                    Console.WriteLine("Withdrawn successful");
//                }
//                else
//                {
//                    Console.WriteLine("Insufficient balance");
//                }
//                return acc.accountbal;
//            }
//        }Console.WriteLine("Account not found");
//        return 0;
//    }

//    public void Transfer(long fromacc, long tooacc, float amount)
//    {
//        Account from = null, to = null;
//        foreach (Account acc in accounts)
//        {
//            if (acc.accountno == fromacc)
//            {
//                from = acc;
//            }
//            if (acc.accountno == tooacc)
//            {
//                to = acc;
//            }
//        }
//        if (from == null || to == null)
//        {
//            Console.WriteLine("Accounts not found");
//            return;
//        }
//        if (from.accountbal >= amount)
//        {
//            from.accountbal = from.accountbal - amount;
//            to.accountbal = to.accountbal + amount;
//            Console.WriteLine("Transfer succesful");
//        }
//        else
//        {
//            Console.WriteLine("Insufficient balance");
//        }
//    }
//    public void Getaccdetails(long accno)
//    {
//        foreach(Account acc in accounts)
//        {
//            if(acc.accountno == accno)
//            {
//                acc.Display();
//                return;
//            }
//        }Console.WriteLine("Account not found");
//    }
//}



//class BankApp
//{
//    static void Main(string[] args)
//    {
//        Bank bank = new Bank();
//        bool run = true;
//        while (run)
//        {
//            Console.WriteLine("=======================");
//            Console.WriteLine("Bank Menu");
//            Console.WriteLine("1.Create account");
//            Console.WriteLine("2.Deposit");
//            Console.WriteLine("3.Withdraw");
//            Console.WriteLine("4.Transfer");
//            Console.WriteLine("5.Getbalance");
//            Console.WriteLine("6.Get account details");
//            Console.WriteLine("7.Exit");
//            Console.WriteLine("Enter your choice");
//            int choice=int.Parse(Console.ReadLine());
//            switch (choice)
//            {
//                case 1:
//            {
//                        Console.WriteLine("Customer ID:");
//                        int cid=int.Parse(Console.ReadLine());
//                        Console.WriteLine("First name:");
//                        string first = Console.ReadLine();
//                        Console.WriteLine("Last name:");
//                        string last = Console.ReadLine();
//                        Console.WriteLine("Email:");
//                        string email = Console.ReadLine();
//                        Console.WriteLine("Phone:");
//                        string phone = Console.ReadLine();
//                        Console.WriteLine("Address:");
//                        string address = Console.ReadLine();
//                        Console.WriteLine("Account Type:");
//                        string acctype= Console.ReadLine();
//                        Console.WriteLine("Initial balance:");
//                        float bal = float.Parse(Console.ReadLine());
//                        Customer cust=new Customer(cid,first,last,email,phone,address);
//                        bank.create_account(cust,acctype,bal);
//                        break;
//            }
//                case 2:
//                    {
//                        Console.WriteLine("Account No:");
//                        long dacc=long.Parse(Console.ReadLine());
//                        Console.WriteLine("Amount to be deposited");
//                        float damt=float.Parse(Console.ReadLine()); 
//                        Console.WriteLine("New balance="+bank.Deposit(dacc,damt));
//                        break;
//                    }

//                case 3:
//                    {
//                        Console.WriteLine("Account No:");
//                        long wacc = long.Parse(Console.ReadLine());
//                        Console.WriteLine("Amount to be withddrawn");
//                        float wamt = float.Parse(Console.ReadLine());
//                        Console.WriteLine("New balance=" + bank.Withdraw(wacc, wamt));
//                        break;
//                    }
//                    case 4:
//                    {
//                        Console.WriteLine("From account:");
//                        long from=long.Parse(Console.ReadLine());
//                        Console.WriteLine("To account:");
//                        long to =long.Parse(Console.ReadLine());    
//                        Console.WriteLine("Enter the amount to beb transferred");
//                        float transammt=float.Parse(Console.ReadLine());
//                        bank.Transfer(from, to, transammt);
//                        break;
//                    }
//                    case 5: {
//                        Console.WriteLine("Account Number:");
//                        long acc=long.Parse(Console.ReadLine());
//                        Console.WriteLine("Balance:"+bank.Get_account_balance(acc));
//                        break; 
//                    }
//                    case 6: {
//                        Console.WriteLine("Account number");
//                        long details=long.Parse(Console.ReadLine());
//                        bank.Getaccdetails(details);
//                        break;
//                    }
//                    case 7: {
//                        run = false;
//                        Console.WriteLine("Exit");
//                        break;
//                    }
//                default:
//                    {
//                        Console.WriteLine("Invalid choice");
//                        break;
//                    }
//            }
//        }
//    }
//}