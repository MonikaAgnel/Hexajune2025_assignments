﻿using System;
using System.Runtime.InteropServices;
using System.Data;
using Microsoft.Data.SqlClient;
public class InvalidAccountException : Exception
{
    public InvalidAccountException(string message) : base(message) { }
}
public class InsufficientFundException : Exception
{
    public InsufficientFundException(string message) : base(message) { }

}

public class OverDraftLimitException : Exception
{
    public OverDraftLimitException(string message) : base(message) { }
}
class Customer
{
    public int customerID { get; set; }
    public string firstName { get; set; }
    public string lastName { get; set; }
    public string Emailaddress { get; set; }

    public DateTime dob {  get; set; }
    public string phoneNumber { get; set; }
    public string address { get; set; }


    public Customer(int c, string first, string last, string email, string no, string add,DateTime dob)
    {
        this.customerID = c;
        this.firstName = first;
        this.lastName = last;
        this.Emailaddress = email;
        this.dob = dob;
        this.address = add;

        //validation of phone no

        if (no.Length == 10)
        {
            bool isvalid = true;
            foreach (char ch in no)
            {
                if (!char.IsDigit(ch))
                {
                    isvalid = false;
                    break;
                }
            }
            if (isvalid)
            {
                this.phoneNumber = no;
            }
            else
            {
                Console.WriteLine("Your number must contain only digits");
                this.phoneNumber = "not provided";
            }
        }
        else
        {
            Console.WriteLine("Your number must contain 10 digits");
        }

        //validation of emailid
        if (!string.IsNullOrEmpty(email) && email.Contains("@") && email.
            Contains("."))
        {
            this.Emailaddress = email;
        }
        else
        {
            Console.WriteLine("Enter a valid email address");
            this.Emailaddress = "not provided";
        }


    }

    public void Printcustomer()
    {
        Console.WriteLine("CustomerId=" + customerID);
        Console.WriteLine("frstname=" + firstName);
        Console.WriteLine("lastname=" + lastName);
        Console.WriteLine("Email addresss=" + Emailaddress);
        Console.WriteLine("Phone number=" + phoneNumber);
        Console.WriteLine("Address=" + address);

    }
}

class Account
{
    public long accountno { get; set; }
    public string accounttype { get; set; }
    public float accountbal { get; set; }
    public Customer accountholder { get; set; }
    private static long lastaccno = 1000;


    public Account(string acctype, float bal, Customer customer)
    {
        this.accountno = ++lastaccno;
        this.accounttype = acctype;
        this.accountbal = bal;
        this.accountholder = customer;
    }

    public virtual void Display()
    {
        Console.WriteLine("Account number=" + accountno);
        Console.WriteLine("Account type=" + accounttype);
        Console.WriteLine("AccountBalance=" + accountbal);
        Console.WriteLine("Customer details:");
        accountholder.Printcustomer();
    }
}


class Transaction
{
    private static long lastTransactionId = 1000;
    public long transactionid { get; set; } 
    public Account accountid { get; set; }
  
    public DateTime Datetime {  get; set; }
    public string transactiontype { get; set; }
    public float amount { get; set; }
    public  Transaction(Account acc,string type,float amt,DateTime dt)
    {
        this.transactionid = ++lastTransactionId;
        this.accountid = acc;
        this.transactiontype = type;
        this.amount = amt;
      
        this.Datetime = dt;
    }
    public void PrintTransaction()
    {
        Console.WriteLine("Transaction Id="+transactionid);
        Console.WriteLine("Account ID=" + accountid);
        Console.WriteLine("Transaction type=" + transactiontype);
        Console.WriteLine("Date/Time=" + Datetime);
        Console.WriteLine("Amount=" +amount);
       
    }
}


class SavingsAccount : Account
{
    public float Interestrate { get; set; }
    public SavingsAccount(float balance, Customer customer) : base("Savings", bal(balance), customer)
    {
        Interestrate = 4.0f;
    }

    private static float bal(float balance)
    {
        if (balance < 500)
        {
            Console.WriteLine("Initial balance is less than 500");
            return 500;
        }
        return balance;
    }

    public override void Display()
    {
        Console.WriteLine("Savings acccount");
        Console.WriteLine("Interest rate=" + Interestrate + "%");
        Console.WriteLine("Balance=" + accountbal);
        accountholder.Printcustomer();
    }
}

class CurrentAccount : Account
{
    public float overdraftLimit { get; set; }
    public CurrentAccount(float balance, Customer customer) : base("Current", balance, customer)
    {
        overdraftLimit = 1000f;
    }
    public override void Display()
    {
        Console.WriteLine("Current acccount");
        Console.WriteLine("overdraft limit=" + overdraftLimit);
        Console.WriteLine("Balance=" + accountbal);
        accountholder.Printcustomer();
    }
}

class ZeroBalanceAccount : Account
{
    public ZeroBalanceAccount(float balance, Customer customer) : base("ZeroBalance", 0, customer)
    {

    }
    public override void Display()
    {
        Console.WriteLine("Zero balance account");
        Console.WriteLine("Balance=" + accountbal);
        accountholder.Printcustomer();
    }
}

interface ICustomerServiceProvider
{
    float GetAccountBalance(long accno);
    float Deposit(long accno, float amount);
    float Withdraw(long accno, float amount);
    void Transfer(long from, long to, float amount);
    void GetAccountDetails(long accno);
}
interface IBankServiceProvider
{
    void CreateAccount(Customer customer, string type, float balance);
    void ListAccounts();
    void CalculateInterest();
}
interface IBankRepository
{
    void CreateAccount(Customer customer, long accno, string type, float balance);
    List<Account> ListAccounts();
    float GetAccountBalance(long accno);
    float Deposit(long accno, float amount);

    float Withdraw(long accno, float amount);
    void Transfer(long fromaacc, long toacc, float amount);
    Account GetAccountDetails(long accno);
    List<Transaction>GetTransactions(long accno,DateTime fromdate,DateTime todate);
    void CalculateInterest();
}
class CustomerServiceProviderImpl : ICustomerServiceProvider
{
    protected List<Account> accountlist = new List<Account>();
    protected List<Transaction> translist= new List<Transaction>(); 
    public float GetAccountBalance(long accno)
    {
        foreach (Account acc in accountlist)
        {
            if (acc.accountno == accno)
            {
                return acc.accountbal;
            }
        }
        throw new InvalidAccountException("Account not found");
    }

    public float Deposit(long accno, float amount)
    {
        foreach (Account acc in accountlist)
        {
            if (acc.accountno == accno)
            {
                acc.accountbal = acc.accountbal + amount;
                return acc.accountbal;
            }
        }
        throw new InvalidAccountException("Account not found");
    }

    public float Withdraw(long accno, float amount)
    {
        foreach (Account acc in accountlist)
        {
            if (acc.accountno == accno)
            {
                if (acc is SavingsAccount && acc.accountbal - amount < 500)
                {
                    throw new InsufficientFundException("Savings account must maintain minimum 500 balance");
                }
                if (acc is CurrentAccount c && acc.accountbal - amount < -c.overdraftLimit)
                {

                    throw new OverDraftLimitException("Overdraft limit exceeded for current account");
                }
                if (acc.accountbal >= amount || acc is CurrentAccount)
                {
                    acc.accountbal = acc.accountbal - amount;
                    return acc.accountbal;
                }

            }
        }
        throw new InvalidAccountException("Account not found");
    }

    public void Transfer(long fromacc, long toacc, float amount)
    {
        Withdraw(fromacc, amount);
        Deposit(toacc, amount);
        Console.WriteLine("Transfer successful");
    }

    public void GetAccountDetails(long accno)
    {
        foreach (Account acc in accountlist)
        {
            if (acc.accountno == accno)
            {
                acc.Display();
                return;
            }
        }
        throw new InvalidAccountException("Account not found");
    }
}

class BankServiceProviderImpl : CustomerServiceProviderImpl, IBankServiceProvider
{
    private string branchname = "HexaBank";
    private string branchaddress = "Chennai";

    public void CreateAccount(Customer customer, string type, float balance)
    {
        Account acc = null;
        if (type == "savings")
        {
            acc = new SavingsAccount(balance, customer);
        }
        else if (type == "current")
        {
            acc = new CurrentAccount(balance, customer);
        }
        else if (type == "ZeroBalance")
        {
            acc = new ZeroBalanceAccount(balance, customer);
        }
        if (acc != null)
        {
            accountlist.Add(acc);
            Console.WriteLine("Account created");
            Console.WriteLine("Account number=" + acc.accountno);
        }
        else
        {
            Console.WriteLine("Invalid account type");
        }
    }

    public void ListAccounts()
    {
        foreach (Account acc in accountlist)
        {
            acc.Display();
            Console.WriteLine();
        }
    }
    public void CalculateInterest()
    {
        foreach (Account acc in accountlist)
        {
            if (acc is SavingsAccount s)
            {
                float interest = (s.accountbal * s.Interestrate) / 100;
                Console.WriteLine("Interest for account" + acc.accountno + ":" + interest);
            }
        }
    }
}


class BankRepositoryImpl : IBankRepository
{
    private readonly string connectionString = "Server=.;Initial Catalog=HMBank;Integrated Security=True;TrustServerCertificate=True;";

    public void CreateAccount(Customer customer, long accno, string type, float balance)
    {
        using SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        SqlCommand cmd1 = new SqlCommand("INSERT INTO Customers(customer_id,first_name,last_name,email,phone_number,dob,address)"+ " VALUES (@id, @first, @last, @email, @phone,@dob, @address)", con);
        cmd1.Parameters.AddWithValue("@id", customer.customerID);
        cmd1.Parameters.AddWithValue("@first", customer.firstName);
        cmd1.Parameters.AddWithValue("@last", customer.lastName);
        cmd1.Parameters.AddWithValue("@email", customer.Emailaddress);
        cmd1.Parameters.AddWithValue("@phone", customer.phoneNumber);
        cmd1.Parameters.AddWithValue("@dob", customer.dob);
        cmd1.Parameters.AddWithValue("@address", customer.address);
      
        cmd1.ExecuteNonQuery();


        SqlCommand cmd2 = new SqlCommand("INSERT INTO Accounts(account_id,account_type,balance,customer_id)"+" VALUES (@accno, @type, @balance, @custid)", con);
        cmd2.Parameters.AddWithValue("@accno", accno);
        cmd2.Parameters.AddWithValue("@type", type);
        cmd2.Parameters.AddWithValue("@balance", balance);
        cmd2.Parameters.AddWithValue("@custid", customer.customerID);
        cmd2.ExecuteNonQuery();
    }

    public List<Account> ListAccounts()
    {
        List<Account> accounts = new List<Account>();
        using SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        string query = "SELECT a.account_id, a.account_type, a.balance, c.customer_id, c.first_name, c.last_name, c.email, c.phone_number" +
            ", c.address, c.dob FROM Accounts a JOIN Customers c ON a.customer_id = c.customer_id";
        SqlCommand cmd = new SqlCommand(query, con);
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            Customer cust = new Customer(
                reader.GetInt32(3),
                reader.GetString(4),
                reader.GetString(5),
                reader.GetString(6),
                reader.GetString(7),
                reader.GetString(8),
                reader.GetDateTime(9)
            );

            Account acc = new Account(
                reader.GetString(1),
                (float)(decimal)reader.GetDecimal(2),
                cust
            );
            acc.accountno = reader.GetInt32(0);

            accounts.Add(acc);
        }
        return accounts;
    }

    public float GetAccountBalance(long accno)
    {
        using SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        SqlCommand cmd = new SqlCommand("SELECT balance FROM Accounts WHERE account_id = @accno", con);
        cmd.Parameters.AddWithValue("@accno", accno);
        object result = cmd.ExecuteScalar();
        return result == null ? throw new InvalidAccountException("Account not found") : Convert.ToSingle(result);
    }

    public float Deposit(long accno, float amount)
    {
        float bal = GetAccountBalance(accno) + amount;
        using SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("UPDATE Accounts SET balance = @bal WHERE account_id = @accno", con);
        cmd.Parameters.AddWithValue("@bal", bal);
        cmd.Parameters.AddWithValue("@accno", accno);
        cmd.ExecuteNonQuery();
        return bal;
    }

    private string GetAccountType(long accno)
    {
        using SqlConnection con = new SqlConnection("Server=.;Initial Catalog=BankDB;Integrated Security=True;TrustServerCertificate=True;");
        con.Open();

        string query = "SELECT account_type FROM Accounts WHERE account_id = @accno";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@accno", accno);

        object result = cmd.ExecuteScalar();
        con.Close();

        if (result == null)
            throw new InvalidAccountException("Account not found");

        return result.ToString();
    }
    public float Withdraw(long accno, float amount)
    {
        float currentBalance = GetAccountBalance(accno);
        string type = GetAccountType(accno);

        if (type == "Savings" && currentBalance - amount < 500)
            throw new InsufficientFundException("Savings must have at least ₹500");
        if (type == "Current" && currentBalance - amount < -1000)
            throw new OverDraftLimitException("Overdraft limit ₹1000 exceeded");

        float newBal = currentBalance - amount;

        using SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("UPDATE Accounts SET balance = @bal WHERE accoun_id = @accno", con);
        cmd.Parameters.AddWithValue("@bal", newBal);
        cmd.Parameters.AddWithValue("@accno", accno);
        cmd.ExecuteNonQuery();
        return newBal;
    }

    public void Transfer(long from, long to, float amount)
    {
        Withdraw(from, amount);
        Deposit(to, amount);
    }

    public Account GetAccountDetails(long accno)
    {
        using SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        string query = "SELECT a.account_type, a.balance, c.customer_id, c.first_name, c.last_name, c.email, c.phone_number, c.address, c.dob FROM Accounts a JOIN Customers c ON a.customer_id = c.customer_id WHERE a.account_id = @accno";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@accno", accno);

        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.Read())
        {
            Customer cust = new Customer(
                reader.GetInt32(2), reader.GetString(3), reader.GetString(4),
                reader.GetString(5), reader.GetString(6), reader.GetString(7),reader.GetDateTime(8)
            );
            Account acc = new Account(reader.GetString(0), (float)(decimal)reader.GetDecimal(1), cust);
            acc.accountno = accno;
            return acc;
        }
        throw new InvalidAccountException("Account not found");
    }

    public List<Transaction> GetTransactions(long accno, DateTime from, DateTime to)
    {
        List<Transaction> transactions = new List<Transaction>();

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT transaction_id, transaction_type, amount, transactions_date FROM Transactions WHERE accountid = @accno AND transaction_date BETWEEN @from AND @to", con);
            cmd.Parameters.AddWithValue("@accno", accno);
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Transaction t = new Transaction(
                    null, // We are not fetching Account object here
                    reader.GetString(1),       // transactiontype
                    (float)reader.GetDouble(2),// amount
                  
                    reader.GetDateTime(4)      // date
                );
                // Manually assign transaction ID
                t.transactionid = reader.GetInt64(0);
                transactions.Add(t);
            }
        }

        return transactions;
    }

    public void CalculateInterest()
    {
        var accounts = ListAccounts();
        foreach (var acc in accounts)
        {
            if (acc.accounttype.ToLower() == "savings")
            {
                float interest = acc.accountbal * 0.04f; // 4% interest
                Console.WriteLine($"Interest for account {acc.accountno}: ₹{interest}");
            }
        }
    }
}





class Program
{
    static void Main(string[] args)
    {
        BankRepositoryImpl repo = new BankRepositoryImpl();

        while (true)
        {
            Console.WriteLine("\n======= Hexaware Bank Menu =======");
            Console.WriteLine("1. Create Account");
            Console.WriteLine("2. View All Accounts");
            Console.WriteLine("3. Get Account Balance");
            Console.WriteLine("4. Deposit");
            Console.WriteLine("5. Withdraw");
            Console.WriteLine("6. Transfer");
            Console.WriteLine("7. Account Details");
            Console.WriteLine("8. Calculate Interest");
            Console.WriteLine("9. Exit");
            Console.Write("Choose option: ");
            int ch = int.Parse(Console.ReadLine());

            switch (ch)
            {
                case 1:
                    Console.Write("Enter Customer ID: ");
                    int id = int.Parse(Console.ReadLine());
                    Console.Write("Enter First Name: ");
                    string first = Console.ReadLine();
                    Console.Write("Enter Last Name: ");
                    string last = Console.ReadLine();
                    Console.Write("Enter Email: ");
                    string email = Console.ReadLine();
                    Console.Write("Enter Phone: ");
                    string phone = Console.ReadLine();
                  
                    Console.WriteLine("Enter the Date of birth((yyyy-mm-dd):");
                    DateTime dob1;
                   string dob = Console.ReadLine();


                    while (!DateTime.TryParseExact(dob, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out dob1))
                    {
                        Console.Write("Invalid format! Enter DOB again (yyyy-MM-dd): ");
                        dob = Console.ReadLine();
                    }
                    Console.Write("Enter Address: ");
                    string address = Console.ReadLine();
                    Console.Write("Enter Account Type (Savings/Current/ZeroBalance): "); 
                    string type = Console.ReadLine();
                    Console.Write("Enter Initial Balance: ");
                    float bal = float.Parse(Console.ReadLine());

                    Customer cust = new Customer(id, first, last, email, phone, address,dob1);
                    long accno = new Random().Next(1001, 9999); // simulate acc no
                    repo.CreateAccount(cust, accno, type, bal);
                    Console.WriteLine($"Account created with Account Number: {accno}");
                    break;

                case 2:
                    List<Account> accounts = repo.ListAccounts();
                    foreach (var acc in accounts)
                    {
                        acc.Display();
                        Console.WriteLine("----------------------------");
                    }
                    break;

                case 3:
                    Console.Write("Enter Account Number: ");
                    long accno1 = long.Parse(Console.ReadLine());
                    float balance = repo.GetAccountBalance(accno1);
                    Console.WriteLine($"Account Balance: ${balance}");
                    break;

                case 4:
                    Console.Write("Enter Account Number: ");
                    long dacc = long.Parse(Console.ReadLine());
                    Console.Write("Enter Amount to Deposit: ");
                    float damt = float.Parse(Console.ReadLine());
                    float newbal = repo.Deposit(dacc, damt);
                    Console.WriteLine($"New Balance: ${newbal}");
                    break;

                case 5:
                    Console.Write("Enter Account Number: ");
                    long wacc = long.Parse(Console.ReadLine());
                    Console.Write("Enter Amount to Withdraw: ");
                    float wamt = float.Parse(Console.ReadLine());
                    float updatedbal = repo.Withdraw(wacc, wamt);
                    Console.WriteLine($"New Balance: ${updatedbal}");
                    break;

                case 6:
                    Console.Write("Enter FROM Account Number: ");
                    long from = long.Parse(Console.ReadLine());
                    Console.Write("Enter TO Account Number: ");
                    long to = long.Parse(Console.ReadLine());
                    Console.Write("Enter Amount to Transfer: ");
                    float tamt = float.Parse(Console.ReadLine());
                    repo.Transfer(from, to, tamt);
                    Console.WriteLine("Transfer Successful");
                    break;

                case 7:
                    Console.Write("Enter Account Number: ");
                    long adetail = long.Parse(Console.ReadLine());
                    Account a = repo.GetAccountDetails(adetail);
                    a.Display();
                    break;

                case 8:
                    repo.CalculateInterest();
                    break;

                case 9:
                    Console.WriteLine("Thank you for using HexaBank!");
                    return;

                default:
                    Console.WriteLine("Invalid Option!");
                    break;
            }
        }
    }
}





