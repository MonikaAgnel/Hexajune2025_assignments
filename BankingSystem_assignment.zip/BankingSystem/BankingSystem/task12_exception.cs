﻿//using BankSystem.Bean.BankSystem.Service.Impl;
//using System;
//using System.Collections.Generic;

//public class InvalidAccountException : Exception
//{
//    public InvalidAccountException(string message) : base(message) { }
//}
//public class InsufficientFundException : Exception
//{
//    public InsufficientFundException(string message) : base(message) { }

//}

//public class OverDraftLimitException : Exception
//{
//    public OverDraftLimitException(string message) : base(message) { }
//}


//namespace BankSystem.Bean
//{
//    class Customer
//    {
//        public int customerID { get; set; }
//        public string firstName { get; set; }
//        public string lastName { get; set; }
//        public string Emailaddress { get; set; }


//        public string phoneNumber { get; set; }
//        public string address { get; set; }


//        public Customer(int c, string first, string last, string email, string no, string add)
//        {
//            this.customerID = c;
//            this.firstName = first;
//            this.lastName = last;
//            this.Emailaddress = email;

//            this.address = add;

//            //validation of phone no

//            if (no.Length == 10)
//            {
//                bool isvalid = true;
//                foreach (char ch in no)
//                {
//                    if (!char.IsDigit(ch))
//                    {
//                        isvalid = false;
//                        break;
//                    }
//                }
//                if (isvalid)
//                {
//                    this.phoneNumber = no;
//                }
//                else
//                {
//                    Console.WriteLine("Your number must contain only digits");
//                    this.phoneNumber = "not provided";
//                }
//            }
//            else
//            {
//                Console.WriteLine("Your number must contain 10 digits");
//            }

//            //validation of emailid
//            if (!string.IsNullOrEmpty(email) && email.Contains("@") && email.
//                Contains("."))
//            {
//                this.Emailaddress = email;
//            }
//            else
//            {
//                Console.WriteLine("Enter a valid email address");
//                this.Emailaddress = "not provided";
//            }


//        }

//        public void Printcustomer()
//        {
//            Console.WriteLine("CustomerId=" + customerID);
//            Console.WriteLine("frstname=" + firstName);
//            Console.WriteLine("lastname=" + lastName);
//            Console.WriteLine("Email addresss=" + Emailaddress);
//            Console.WriteLine("Phone number=" + phoneNumber);
//            Console.WriteLine("Address=" + address);

//        }
//    }


//    class Account
//    {
//        public long accountno { get; set; }
//        public string accounttype { get; set; }
//        public float accountbal { get; set; }
//        public Customer accountholder { get; set; }
//        private static long lastaccno = 1000;


//        public Account(string acctype, float bal, Customer customer)
//        {
//            this.accountno = ++lastaccno;
//            this.accounttype = acctype;
//            this.accountbal = bal;
//            this.accountholder = customer;
//        }

//        public virtual void Display()
//        {
//            Console.WriteLine("Account number=" + accountno);
//            Console.WriteLine("Account type=" + accounttype);
//            Console.WriteLine("AccountBalance=" + accountbal);
//            Console.WriteLine("Customer details:");
//            accountholder.Printcustomer();
//        }
//    }

//    class SavingsAccount : Account
//    {
//        public float Interestrate { get; set; }
//        public SavingsAccount(float balance, Customer customer) : base("Savings", bal(balance), customer)
//        {
//            Interestrate = 4.0f;
//        }

//        private static float bal(float balance)
//        {
//            if (balance < 500)
//            {
//                Console.WriteLine("Initial balance is less than 500");
//                return 500;
//            }
//            return balance;
//        }

//        public override void Display()
//        {
//            Console.WriteLine("Savings acccount");
//            Console.WriteLine("Interest rate=" + Interestrate + "%");
//            Console.WriteLine("Balance=" + accountbal);
//            accountholder.Printcustomer();
//        }
//    }

//    class CurrentAccount : Account
//    {
//        public float overdraftLimit { get; set; }
//        public CurrentAccount(float balance, Customer customer) : base("Current", balance, customer)
//        {
//            overdraftLimit = 1000f;
//        }
//        public override void Display()
//        {
//            Console.WriteLine("Current acccount");
//            Console.WriteLine("overdraft limit=" + overdraftLimit);
//            Console.WriteLine("Balance=" + accountbal);
//            accountholder.Printcustomer();
//        }
//    }

//    class ZeroBalanceAccount : Account
//    {
//        public ZeroBalanceAccount(float balance, Customer customer) : base("ZeroBalance", 0, customer)
//        {

//        }
//        public override void Display()
//        {
//            Console.WriteLine("Zero balance account");
//            Console.WriteLine("Balance=" + accountbal);
//            accountholder.Printcustomer();
//        }
//    }

//    namespace BankSystem.Service
//    {

//        interface ICustomerServiceProvider
//        {
//            float GetAccountBalance(long accno);
//            float Deposit(long accno, float amount);
//            float Withdraw(long accno, float amount);
//            void Transfer(long from, long to, float amount);
//            void GetAccountDetails(long accno);
//        }
//        interface IBankServiceProvider
//        {
//            void CreateAccount(Customer customer, string type, float balance);
//            void ListAccounts();
//            void CalculateInterest();
//        }
//    }

//    namespace BankSystem.Service.Impl
//    {
//        class CustomerServiceProviderImpl : ICustomerServiceProvider
//        {
//            protected List<Account> accountlist = new List<Account>();
//            public float GetAccountBalance(long accno)
//            {
//                foreach (Account acc in accountlist)
//                {
//                    if (acc.accountno == accno)
//                    {
//                        return acc.accountbal;
//                    }
//                }
//                throw new InvalidAccountException("Account not found");
//            }

//            public float Deposit(long accno, float amount)
//            {
//                foreach (Account acc in accountlist)
//                {
//                    if (acc.accountno == accno)
//                    {
//                        acc.accountbal = acc.accountbal + amount;
//                        return acc.accountbal;
//                    }
//                }
//                throw new InvalidAccountException("Account not found");
//            }

//            public float Withdraw(long accno, float amount)
//            {
//                foreach (Account acc in accountlist)
//                {
//                    if (acc.accountno == accno)
//                    {
//                        if (acc is SavingsAccount && acc.accountbal - amount < 500)
//                        {
//                            throw new InsufficientFundException("Savings account must maintain minimum 500 balance");
//                        }
//                        if (acc is CurrentAccount c && acc.accountbal - amount < -c.overdraftLimit)
//                        {

//                            throw new OverDraftLimitException("Overdraft limit exceeded for current account");
//                        }
//                        if (acc.accountbal >= amount || acc is CurrentAccount)
//                        {
//                            acc.accountbal = acc.accountbal - amount;
//                            return acc.accountbal;
//                        }

//                    }
//                }
//                throw new InvalidAccountException("Account not found");
//            }

//            public void Transfer(long fromacc, long toacc, float amount)
//            {
//                Withdraw(fromacc, amount);
//                Deposit(toacc, amount);
//                Console.WriteLine("Transfer successful");
//            }

//            public void GetAccountDetails(long accno)
//            {
//                foreach (Account acc in accountlist)
//                {
//                    if (acc.accountno == accno)
//                    {
//                        acc.Display();
//                        return;
//                    }
//                }
//                throw new InvalidAccountException("Account not found");
//            }
//        }

//        class BankServiceProviderImpl : CustomerServiceProviderImpl, BankSystem.Service.IBankServiceProvider
//        {
//            private string branchname = "HexaBank";
//            private string branchaddress = "Chennai";

//            public void CreateAccount(Customer customer, string type, float balance)
//            {
//                Account acc = null;
//                if (type == "savings")
//                {
//                    acc = new SavingsAccount(balance, customer);
//                }
//                else if (type == "current")
//                {
//                    acc = new CurrentAccount(balance, customer);
//                }
//                else if (type == "ZeroBalance")
//                {
//                    acc = new ZeroBalanceAccount(balance, customer);
//                }
//                if (acc != null)
//                {
//                    accountlist.Add(acc);
//                    Console.WriteLine("Account created");
//                    Console.WriteLine("Account number=" + acc.accountno);
//                }
//                else
//                {
//                    Console.WriteLine("Invalid account type");
//                }
//            }

//            public void ListAccounts()
//            {
//                foreach (Account acc in accountlist)
//                {
//                    acc.Display();
//                    Console.WriteLine();
//                }
//            }
//            public void CalculateInterest()
//            {
//                foreach (Account acc in accountlist)
//                {
//                    if (acc is SavingsAccount s)
//                    {
//                        float interest = (s.accountbal * s.Interestrate) / 100;
//                        Console.WriteLine("Interest for account" + acc.accountno + ":" + interest);
//                    }
//                }
//            }
//        }
//    }


//    namespace BankSystem.App
//    {
//        class BankApp
//        {
//            static void Main(string[] args)
//            {
//                BankServiceProviderImpl bank = new BankServiceProviderImpl();

//                while (true)
//                {
//                    Console.WriteLine("=======================");
//                    Console.WriteLine("Bank Menu");
//                    Console.WriteLine("1.Create account");
//                    Console.WriteLine("2.Deposit");
//                    Console.WriteLine("3.Withdraw");
//                    Console.WriteLine("4.Transfer");
//                    Console.WriteLine("5.Getbalance");
//                    Console.WriteLine("6.Get account details");
//                    Console.WriteLine("7.Exit");
//                    Console.WriteLine("Enter your choice");
//                    int choice = int.Parse(Console.ReadLine());
//                    if (choice == 9) break;
//                    try
//                    {
//                        switch (choice)
//                        {
//                            case 1:
//                                {
//                                    Console.WriteLine("Customer ID:");
//                                    int cid = int.Parse(Console.ReadLine());
//                                    Console.WriteLine("First name:");
//                                    string first = Console.ReadLine();
//                                    Console.WriteLine("Last name:");
//                                    string last = Console.ReadLine();
//                                    Console.WriteLine("Email:");
//                                    string email = Console.ReadLine();
//                                    Console.WriteLine("Phone:");
//                                    string phone = Console.ReadLine();
//                                    Console.WriteLine("Address:");
//                                    string address = Console.ReadLine();
//                                    Console.WriteLine("Account Type:");
//                                    string acctype = Console.ReadLine();
//                                    Console.WriteLine("Initial balance:");
//                                    float bal = float.Parse(Console.ReadLine());
//                                    Customer cust = new Customer(cid, first, last, email, phone, address);
//                                    bank.CreateAccount(cust, acctype, bal);
//                                    break;
//                                }
//                            case 2:
//                                {
//                                    Console.WriteLine("Account No:");
//                                    long dacc = long.Parse(Console.ReadLine());
//                                    Console.WriteLine("Amount to be deposited");
//                                    float damt = float.Parse(Console.ReadLine());
//                                    Console.WriteLine("New balance=" + bank.Deposit(dacc, damt));
//                                    break;
//                                }

//                            case 3:
//                                {
//                                    Console.WriteLine("Account No:");
//                                    long wacc = long.Parse(Console.ReadLine());
//                                    Console.WriteLine("Amount to be Withdrawn");
//                                    float wamt = float.Parse(Console.ReadLine());
//                                    Console.WriteLine("New balance=" + bank.Withdraw(wacc, wamt));
//                                    break;
//                                }
//                            case 4:
//                                {
//                                    Console.WriteLine("From account:");
//                                    long from = long.Parse(Console.ReadLine());
//                                    Console.WriteLine("To account:");
//                                    long to = long.Parse(Console.ReadLine());
//                                    Console.WriteLine("Enter the amount to be transferred");
//                                    float transammt = float.Parse(Console.ReadLine());
//                                    bank.Transfer(from, to, transammt);
//                                    break;
//                                }
//                            case 5:
//                                {
//                                    Console.WriteLine("Account Number:");
//                                    long acc = long.Parse(Console.ReadLine());
//                                    Console.WriteLine("Balance:" + bank.GetAccountBalance(acc));
//                                    break;
//                                }
//                            case 6:
//                                {
//                                    Console.WriteLine("Account number");
//                                    long details = long.Parse(Console.ReadLine());
//                                    bank.GetAccountDetails(details);
//                                    break;
//                                }
//                            case 7:
//                                {
//                                    bank.ListAccounts();
//                                    break;
//                                }
//                            default:
//                                {
//                                    bank.CalculateInterest();
//                                    break;
//                                }
//                        }
//                    }
//                    catch (InvalidAccountException ex)
//                    {
//                        Console.WriteLine("Error:" + ex.Message);
//                    }
//                    catch (InsufficientFundException ex)
//                    {
//                        Console.WriteLine("Error:" + ex.Message);
//                    }
//                    catch (OverDraftLimitException ex)
//                    {
//                        Console.WriteLine("Error:" + ex.Message);
//                    }
//                    catch (Exception ex)
//                    {
//                        Console.WriteLine("Error:" + ex.Message);
//                    }
//                }
//            }
//        }

//    }

//}
