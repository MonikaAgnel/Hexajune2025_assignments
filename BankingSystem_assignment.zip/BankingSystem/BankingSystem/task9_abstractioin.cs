﻿//using System;

//abstract class Bankaccount
//{
//    protected int accountNumber {  get; set; }
//    protected string customername {  get; set; }
//    protected float balance {  get; set; }

//    public Bankaccount()
//    {

//    }
//    public Bankaccount(int accno, string name, float bal)
//    {
//        accountNumber = accno;
//        customername = name;
//        balance = bal;
//    }


//    public void display()
//    {
//        Console.WriteLine("Account Number=" + accountNumber);
//        Console.WriteLine("Customer Name=" + customername);
//        Console.WriteLine("Balance=" + balance);
//    }
//    public abstract void Deposit(float amount);
//    public abstract void Withdraw(float amount);
//    public abstract void CalculateInterest();
//}




//class Savingsaccount : Bankaccount
//{
//    private float interestrate;
//    public Savingsaccount(int accno, string name, float bal, float rate):base(accno, name, bal) 
//    {
//        interestrate = rate;
//    }

//    public override void Deposit(float amount)
//    {
//        if (amount > 0)
//        {
//            balance = balance + amount;
//            Console.WriteLine("Deposit successfull");
//        }
//        else
//        {
//            Console.WriteLine("Invalid deposit amount");
//        }
//    }


//    public override void Withdraw(float amount)
//    {
//        if (amount > 0 && amount <= balance)
//        {
//            balance = balance - amount;
//            Console.WriteLine("Withdraw successfull");
//        }
//        else
//        {
//            Console.WriteLine("Insufficient balance");
//        }
//    }

//    public override void CalculateInterest()
//    {
//        float interest = balance * interestrate / 100;
//        balance = balance + interest;
//        Console.WriteLine("Interest amount=" + interest);
//    }
//}

//class Currentaccount : Bankaccount
//{
//    private  float overdraftlimit = 1000f;

//    public Currentaccount(int accno, string name, float bal) : base(accno, name, bal)
//    {

//    }

//    public override void Deposit(float amount)
//    {
//        if (amount > 0)
//        {
//            balance = balance + amount;
//            Console.WriteLine("Deposit successfull");
//        }
//        else
//        {
//            Console.WriteLine("Invalid deposit");
//        }
//    }


//    public override void Withdraw(float amount)
//    {
//        if (amount <= balance + overdraftlimit)
//        {
//            balance = balance - amount;
//            Console.WriteLine("Withdraw successfull");
//        }
//        else
//        {
//            Console.WriteLine("withdrawal exceeds overdraft limit");
//        }
//    }
//    public override void CalculateInterest()
//    {
//        Console.WriteLine("No interest for current account");
//    }

//}


//class Bank
//{
//    static void Main(string[] args)
//    {
//        Bankaccount account = null;

//        Console.WriteLine("Choose Account Type:");
//        Console.WriteLine("1. Savings Account");
//        Console.WriteLine("2. Current Account");
//        Console.Write("Enter choice: ");
//        int choice = int.Parse(Console.ReadLine());

//        switch (choice)
//        {
//            case 1:
//                account = new Savingsaccount(1001, "Riya Das", 5000, 4.5f);
//                break;
//            case 2:
//                account = new Currentaccount(1002, "Riya Das", 2000);
//                break;
//            default:
//                Console.WriteLine("Invalid choice.");
//                return;
//        }

//        account.display();
//        account.Deposit(500);
//        account.Withdraw(300);
//        account.CalculateInterest();
//    }
//}



