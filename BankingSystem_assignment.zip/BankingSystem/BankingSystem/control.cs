﻿//using System;
//class Helloworld
//{
//    static void Main(String[] args)
//    {
//        Console.WriteLine("Enter the credit score");
//        int creditscore=int.Parse(Console.ReadLine());
//        Console.WriteLine("Enter the annual income");
//        int annual_income=int.Parse(Console.ReadLine());
//        if(creditscore>700 && annual_income >= 50000)
//        {
//            Console.WriteLine("You are eligible for the loan");
//        }
//        else
//        {
//            Console.WriteLine("You are not eligible for the loan");
//        }
//    }
//}


//using System;
//using System.Transactions;
//class Helloworld
//{
//    static void Main(String[] args)
//    {
//        Console.WriteLine("Enter the current balance");
//        int bal = int.Parse(Console.ReadLine());

//        Console.WriteLine("Enter 1 if you want to check balance \nEnter 2 if you want to withdraw \nEnter 3 if you want to deposit");
//        int num = int.Parse(Console.ReadLine());
//        if (num == 1)
//        {
//            Console.WriteLine("You have chosen to check balance\ncurrent balance=" + bal);
//        }
//        else if (num == 2)
//        {
//            Console.WriteLine("Enter the amount you want to withdraw");
//            int amt = int.Parse(Console.ReadLine());
//            if (amt < bal)
//            {
//                if (amt % 100 == 0 || amt % 500 == 0)
//                {

//                    bal = bal - amt;
//                    Console.WriteLine("Withdrawn successful!!!");
//                    Console.WriteLine("current bal=" + bal);
//                }
//                else
//                {
//                    Console.WriteLine("Enter the amount in terms of 100 and 500");
//                }
//            }
//            else
//            {
//                Console.WriteLine("You do not have enough balance");
//            }

//        }
//        else if (num == 3)
//        {
//            Console.WriteLine("Enter the amount you want to deposit");
//            int amt = int.Parse(Console.ReadLine());
//            bal = bal + amt;
//            Console.WriteLine("Deposit sucessfull!!!");
//            Console.WriteLine("current balance=" + bal);
//        }
//        else
//        {
//            Console.WriteLine("Pls enter a valid number");
//        }



//    }
//}



//using System;

//class Helloworld
//{
//    static void Main(String[] args)
//    {
//        Console.WriteLine("Enter the account type:");
//        string type=Console.ReadLine();
//        Console.WriteLine("Enter the No of Customers:");
//        int customer = int.Parse(Console.ReadLine());
//        if (type == "savings")
//        {

//            for (int i = 1; i <= customer; i++)
//            {

//                Console.WriteLine("Customer " + i);
//                Console.WriteLine("Enter Initial balance:");
//                double ibal = double.Parse(Console.ReadLine());
//                Console.WriteLine("Enter the annual interest rate");
//                double rate = double.Parse(Console.ReadLine());
//                Console.WriteLine("Enter the no of years");
//                int yr = int.Parse(Console.ReadLine());
//                double future = ibal * Math.Pow((1 + rate / 100), yr);
//                Console.WriteLine(future);
//            }
//        }
//        else
//        {
//            Console.WriteLine("No interest for current account");
//        }
//    }
//}



//looping and data validatiion

//using System;
//class Validation
//{
//    static void Main(string[] args)
//    {
//        int[] accountnumber = { 101, 102, 103, 104, 105 };
//        double[] balance = { 500.76, 290.09, 3000.00, 2890.00, 60000.76 };
//        bool isvalid = false;
//        while (!isvalid) {
//            Console.WriteLine("Enter the account number: ");
//            string num=Console.ReadLine(); 
//            int enteredaccountno;
//            bool number=int.TryParse(num,out enteredaccountno);
//            if (!number)
//            {
//                Console.WriteLine("Enter a valid accountnumber");
//                continue;
//            }
//            bool accountfound = false;
//            for (int i = 0; i < accountnumber.Length; i++)
//            {
//                if (enteredaccountno == accountnumber[i]) {
//                    Console.WriteLine("Account found");
//                    Console.WriteLine("Your account balance is " + balance[i]);
//                    accountfound = true;
//                    isvalid = true;
//                    break;
//                }

//            }
//            if (!accountfound) {
//                Console.WriteLine("Account not found, try again");
//            }
//        }Console.WriteLine("Thank you for banking");
//    }
//}



////password validation
//using System;
//class Password
//{
//    static void Main(string[] args)
//    {
//        Console.WriteLine("Enter your Password");
//        String password = Console.ReadLine();
//        bool haschar = false;
//        bool hasdigit = false;
//        if (password.Length < 8)
//        {
//            Console.WriteLine("Your password must have atleast 8 characters");
//        }
//        else
//        {
//            foreach (char c in password)
//            {
//                if (char.IsUpper(c))
//                    haschar = true;

//                if (char.IsDigit(c))
//                    hasdigit = true;
//            }
//        }
//        if (haschar && hasdigit) { Console.WriteLine("Password is valid"); }
//        else
//        {
//            if (!haschar)
//            {
//                Console.WriteLine("The password must contain atleast 1 uppercase");
//            }
//            if (!hasdigit)
//            {
//                Console.WriteLine("The password must contain atleast 1 digit");
//            }
//        }
//    }
//}


////password validation task 6
//using System;
//using System.Collections.Generic;
//class Password
//{
//    static void Main(string[] args)
//    {
//        List<string> list = new List<string>();
//        bool running = true;
//        while (running)
//        {
//            Console.WriteLine("Choose an option");
//            Console.WriteLine("1.Deposit");
//            Console.WriteLine("2.Withdraw");
//            Console.WriteLine("3.Exit");
//            Console.WriteLine("Enter a option:");
//            int option = int.Parse(Console.ReadLine());
//            switch (option)
//            {
//                case 1:
//                    {
//                        Console.WriteLine("Enter the amount you want to deposit:");
//                        int amount = int.Parse(Console.ReadLine());
//                        list.Add("deposited amt=" + amount);
//                        Console.WriteLine("Deposit successfull");
//                        break;
//                    }
//                case 2:
//                    {
//                        Console.WriteLine("Enter the amount you want to withdraw:");
//                        int amount = int.Parse(Console.ReadLine());
//                        list.Add("withdraw amt=" + amount);
//                        Console.WriteLine("withdraw successfull");
//                        break;
//                    }
//                case 3:
//                    {
//                        running = false;
//                        break;
//                    }
//                default:
//                    {
//                        Console.WriteLine("Invalid option");
//                        break;
//                    }
//            }
//            Console.WriteLine("==================================");
//            Console.WriteLine("Transaction history");
//            if (list.Count == 0)
//            {
//                Console.WriteLine("No transaction");
//            }
//            else
//            {
//                foreach (string i in list)
//                {
//                    Console.WriteLine(i);
//                }
//            }
//        }
//    }
//}
