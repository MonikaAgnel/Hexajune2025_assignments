﻿//using System;
//class Customer
//{
//    private int customerID { get; set; }
//    private string firstName { get; set; }
//    private string lastName { get; set; }
//    private string email { get; set; }
//    private string phoneno { get; set; }
//    private string address { get; set; }

//    public Customer()
//    {
//    }
//    public Customer(int c, string first, string last, string e, string no, string add)
//    {
//        customerID = c;
//        firstName = first;
//        lastName = last;
//        email = e;
//        phoneno = no;
//        address = add;

//    }


//    public void info()
//    {
//        Console.WriteLine("Customer Id =" + customerID);
//        Console.WriteLine("First name =" + firstName);
//        Console.WriteLine("Last name =" + lastName);
//        Console.WriteLine("Email Address =" + email);
//        Console.WriteLine("Phone number =" + phoneno);
//        Console.WriteLine("Address=" + address);
//    }



//}





//class Account
//{
//    protected int account_no { get; set; }
//   protected string account_type { get; set; }
//   protected float account_bal { get; set; }

//    public Account()
//    {

//    }
//    public Account(int no, string type, float abal)
//    {
//        account_no = no;
//        account_type = type;
//        account_bal = abal;
//    }


//    public void display()
//    {
//        Console.WriteLine("Account Number=" + account_no);
//        Console.WriteLine("Account Type=" + account_type);
//        Console.WriteLine("Account Balance=" + account_bal);
//    }

//    public void Deposit(float amount)
//    {
//        if (amount > 0)
//        {
//            Console.WriteLine("The amount to be deposited =" + amount);
//            account_bal = account_bal + amount;
//            Console.WriteLine("amount deposited successfully");
//            Console.WriteLine("current balance=" + account_bal);
//        }
//        else
//        {
//            Console.WriteLine("Invalid deposit amount");
//        }
//    }

//    public void Deposit(int amount)
//    {
//       Deposit((float)amount);
//    }
//    public void Deposit(double amount)
//    {
//        Deposit((float)amount);
//    }

//    public void Withdraw(float amount)
//    {
//        if (amount > 0 && amount <= account_bal)
//        {
//            Console.WriteLine("The amount to be Withdrawn =" + amount);
//            account_bal = account_bal - amount;
//            Console.WriteLine("Withdrawn succesfull");
//            Console.WriteLine("current balance=" + account_bal);
//        }
//        else
//        {
//            Console.WriteLine("Invalid withdraw amount");
//        }
//    }

//    public void Withdraw(int amount)
//    {
//        Withdraw((float)amount);
//    }
//    public void Withdraw(double amount)
//    {
//        Withdraw((float)amount);
//    }

//    public virtual void calculate_interest()
//    {
//        //if (account_type.ToLower() == "savings")
//        //{
//        //    float interest = account_bal * 4.5f / 100;
//        //    account_bal = account_bal + interest;
//        //    Console.WriteLine("Interest amount=" + interest);
//        //    Console.WriteLine("Current balance =" + account_bal);
//        //}
//         Console.WriteLine("No interest rate for this account");
//    }
//}



//class SavingsAccount : Account
//{
//   public  float interest {  get; set; }  

//    public  SavingsAccount(int no, string type, float abal,float rate):base(no,type,abal)
//    {
//        interest = rate;
//    }

//    public override void calculate_interest()
//    {
        
//            float interest = account_bal * 4.5f / 100;
//            account_bal = account_bal + interest;
//            Console.WriteLine("Interest amount=" + interest);
//            Console.WriteLine("Current balance =" + account_bal);
        
//    }
//}


//class CurrentAccount : Account
//{
//    public float overdraft = 1000;
//    public CurrentAccount(int no, string type, float abal):base(no,type,abal)
//    {
        
//    }

//    public void Withdraw(float amount)
//    {
//        if (amount > 0 && amount <= account_bal+overdraft)
//        {
//            Console.WriteLine("The amount to be Withdrawn =" + amount);
//            account_bal = account_bal - amount;
//            Console.WriteLine("Withdrawn succesfull");
//            Console.WriteLine("current balance=" + account_bal);
//        }
//        else
//        {
//            Console.WriteLine("Invalid withdraw amount");
//        }
//    }
//}




//class Bank
//{
//    static void Main(string[] args)
//    {
        
//        Customer customer = new Customer(101, "Riya", "Das", "riya@gmailcom", "9856472549", "chennai");
//        Console.WriteLine("customer info");
//        Console.WriteLine("==========================");
//        customer.info();
//        Console.WriteLine();
//        Console.WriteLine("Enter 1 for savings account\n2 for current account");
//        int choice=int.Parse(Console.ReadLine());
//        Account account=null;
//        switch (choice)
//        {
//            case 1:
//                account  = new SavingsAccount(101,"savings",1000,4.5f);
//                break;
//            case 2:
//              account = new CurrentAccount(101,"current",5000);
//                break;
//                default:
//                Console.WriteLine("Invalid number");
//                break;
//        }

//        Console.WriteLine("account info");
//        Console.WriteLine("===========================");
//        account.display();
//        Console.WriteLine();

//        Console.WriteLine("deposit");
//        Console.WriteLine("=============================");
//        account.Deposit(3000);
//        Console.WriteLine();

//        Console.WriteLine("withdraw");
//        Console.WriteLine("============================");
//        account.Withdraw(2000);
//        Console.WriteLine();

//        Console.WriteLine("Interest rate");
//        Console.WriteLine("============================");
//        account.calculate_interest();

//    }

//}