﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using Microsoft.Data.SqlClient;


//Exception handling
public class InvalidEmailFormatException : Exception
{
    public InvalidEmailFormatException(string message) : base(message) { }
}

public class SalaryCalculation : Exception
{
    public SalaryCalculation(string message) : base(message) { }
}


public class FileUploadException: Exception
{
    public FileUploadException(string message) : base(message) { }

}

public class ApplicationDeadlineException: Exception
{
    public ApplicationDeadlineException(string message) : base(message) { }
}

public class DatabaseConnection : Exception
{
    public DatabaseConnection(string message) : base(message) { }
}
//Joblisting class

public class JobListing
{
    public int JobId {  get; set; }
    public int CompanyId {  get; set; }
    public string JobTitle {  get; set; }
    public string JobDescription { get; set; }
    public string JobLocation {  get; set; }
    public decimal Salary {  get; set; }
    public string JobType {  get; set; }
    public DateTime PostedDate { get; set; }
    public DateTime DeadLineDate { get; set; }

    public List<JobApplication> app = new List<JobApplication>();

    public void Apply(int ApplicationId,string CoverLetter)
    {
        try
        {
            if (DateTime.Now > this.DeadLineDate)
                throw new ApplicationDeadlineException("Application Deadline has passed");
            JobApplication application = new JobApplication();
            application.JobId = this.JobId;
            application.ApplicationId = ApplicationId;
            application.CoverLetter = CoverLetter;
            application.ApplicationDate = DateTime.Now;
            app.Add(application);
        }catch(ApplicationDeadlineException ex)
        {
            Console.WriteLine("Apllication Error: " + ex.Message);
        }
    }

    public List<Applicant> GetApplicants()
    {
      List<Applicant>result=new List<Applicant>();
        foreach(var item in app)
        {
            Applicant applicant = new Applicant();
            applicant.ApplicantId=item.ApplicationId;
            result.Add(applicant);
        }return result;
    }


    //company class

    public class Company
    {
        public int CompanyId { get; set; }
        public string CompanyName {  get; set; }   
        public string Location {  get; set; }
        public List<JobListing> JobList = new List<JobListing>();

        public void PostJob(string JobTitle,string JobDescription,string JobLocation,decimal Salary,string JobType)
        {
            JobListing job = new JobListing();
            job.JobId = JobList.Count + 1;
            job.CompanyId = this.CompanyId;
            job.JobTitle = JobTitle;
            job.JobDescription = JobDescription;
            job.JobLocation = JobLocation;
            job.Salary = Salary;    
            job.JobType = JobType;
            job.PostedDate = DateTime.Now;
           
        }
        public List<JobListing> GetJob()
        {
            return JobList;
        }
    }

    //applicant class
    public class Applicant
    {
        public int ApplicantId { get; set; }    
        public string FirstName {  get; set; }
        public string LastName { get; set; } 
        public string Email {  get; set; }
        public string Phone {  get; set; }
        public string Resume { get; set; }


        public void CreateProfile(string Email, string FirstsName, string LastName, string Phone)
        {
            try
            {
                if (!Email.Contains("@") || !Email.Contains("."))
                {
                    throw new InvalidEmailFormatException("Invalid Email format");
                }
                this.Email = Email;
                this.FirstName = FirstsName;
                this.LastName = LastName;
                this.Phone = Phone;
            }
            catch (InvalidEmailFormatException ex)
            {
                Console.WriteLine("Error: "+ex.Message);
            }
            
        }

        public void ApplyForJob(JobListing job, string CoverLetter)
        {
            job.Apply(ApplicantId, CoverLetter);
        }
        public void UploadResume(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                    throw new FileUploadException("Resume file not found!");

                FileInfo file = new FileInfo(filePath);
                if (file.Length > 5 * 1024 * 1024)
                    throw new FileUploadException("File size exceeds 5MB!");

                if (file.Extension != ".pdf" && file.Extension != ".docx")
                    throw new FileUploadException("Unsupported file format. Only PDF and DOCX allowed.");

                this.Resume = filePath;
                Console.WriteLine("Resume uploaded successfully.");
            }
            catch (FileUploadException ex)
            {
                Console.WriteLine("File Upload Error: " + ex.Message);
            }
        }

    }

    //Job application class
    public class JobApplication
    {
        public int ApplicationId { get; set; }
        public int JobId { get; set; }
        public int ApplicantId { get; set; }
        public DateTime ApplicationDate { get; set; }
        public string CoverLetter { get; set; }
    }


    //database manager class
public class DatabaseManager
    {
        private  string connection= "Server=.;Initial Catalog=CareerHub;Integrated Security=True;TrustServerCertificate=True;";
        //initializing the database
        public void InitializeDatabase()
        {
            using SqlConnection con=new SqlConnection(connection);
            con.Open();

            string CreateCompanies = @"create table Companies (company_id int primary key,company_name varchar(255),location varchar(255));";
            string CreateJobs = @"create table Jobs(job_id int primary key,company_id int,job_title varchar(255),job_description text,job_location varchar(255),salary decimal(18,2),job_type varchar(255),posted_date datetime,foreign key (company_id) references companies(company_id));";
            string CreateApplicants = @"create table Applicants(applicant_id int primary key,firstname varchar(100),lastname varchar(100),email varchar(255),phone nvarchar(100),resume text);";
            string CreateApplication= @"create table Applications(application_id int primary key,job_id int,applicant_id int,application_date datetime,coverletter text,foreign key(job_id) references jobs(job_id),foreign key(application_id) references applicants(applicant_id));";

            new SqlCommand(CreateCompanies, con).ExecuteNonQuery();
            new SqlCommand(CreateJobs, con).ExecuteNonQuery();
            new SqlCommand(CreateApplicants, con).ExecuteNonQuery();
            new SqlCommand(CreateApplication, con).ExecuteNonQuery();

            Console.WriteLine("Database initialization successful");

        }
        //insert job
        public void InsertJobListing(JobListing job)
        {
            using SqlConnection con=new SqlConnection(connection);
            con.Open();
            string query = @"insert into Jobs values(@id,@cid,@title,@desc,@loc,@type,@date)";
            SqlCommand cmd=new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", job.JobId);
            cmd.Parameters.AddWithValue("@cid", job.CompanyId);
            cmd.Parameters.AddWithValue("@title", job.JobTitle);
            cmd.Parameters.AddWithValue("@desc", job.JobDescription);
            cmd.Parameters.AddWithValue("@loc", job.JobLocation);
            cmd.Parameters.AddWithValue("@sal", job.Salary);
            cmd.Parameters.AddWithValue("@type", job.JobType);
            cmd.Parameters.AddWithValue("@date", job.PostedDate);

            cmd.ExecuteNonQuery();
        }
        //insert the company
        public void InsertCompany(Company comp)
        {
            using SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = @"insert into Companies values(@id,@name,@loc)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", comp.CompanyId);
            cmd.Parameters.AddWithValue("@cid", comp.CompanyName);
            cmd.Parameters.AddWithValue("@title", comp.Location);

            cmd.ExecuteNonQuery();
            
        }
        //insert applicant
        public void InsertApplicant(Applicant iapp)
        {
            using SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = @"insert into Applicant values(@id,@fname,@lname,@mail,@phone,@res)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", iapp.ApplicantId);
            cmd.Parameters.AddWithValue("@cid", iapp.FirstName);
            cmd.Parameters.AddWithValue("@title", iapp.LastName);
            cmd.Parameters.AddWithValue("@title", iapp.Email);
            cmd.Parameters.AddWithValue("@title", iapp.Phone);
            cmd.Parameters.AddWithValue("@title", iapp.Resume);

            cmd.ExecuteNonQuery();
        }
        //insert job application
        public void InsertJobApplication(JobApplication jobapp)
        {
            using SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = @"insert into Applications values(@appid,@jobid,@applicantid,@date,@letter)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", jobapp.ApplicantId);
            cmd.Parameters.AddWithValue("@cid", jobapp.JobId);
            cmd.Parameters.AddWithValue("@title", jobapp.ApplicantId);
            cmd.Parameters.AddWithValue("@title", jobapp.ApplicationDate);
            cmd.Parameters.AddWithValue("@title", jobapp.CoverLetter);
            
            cmd.ExecuteNonQuery();
        }
        //get job listing
        public List<JobListing> GetJobListings()
        {
            List<JobListing>list=new List<JobListing>();
            try
            {
                using SqlConnection con = new SqlConnection(connection);
                con.Open();

                string query = "select * from Jobs";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    JobListing job = new JobListing();
                    job.JobId = reader.GetInt32(0);
                    job.CompanyId = reader.GetInt32(1);
                    job.JobTitle = reader.GetString(2);
                    job.JobDescription = reader.GetString(3);
                    job.JobLocation = reader.GetString(4);
                    job.Salary = reader.GetDecimal(5);
                    job.JobType = reader.GetString(6);
                    job.PostedDate = reader.GetDateTime(7);
                    list.Add(job);
                }
            }
                catch(SqlException ex){
                    Console.WriteLine("Error: "+ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            return list;
        }
        //get theh list companies
        public List<Company> GetCompanies()
        {
            List<Company> list = new List<Company>();
            using SqlConnection con = new SqlConnection(connection);
            con.Open();

            string query = "select * from Companies";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Company company = new Company();
                company.CompanyId=reader.GetInt32(0);
                company.CompanyName = reader.GetString(1);
                company.Location= reader.GetString(2);  
                list.Add(company);
            }
            return list;
        }
        //get the applicants
        public List<Applicant> GetApplicants()
        {
            List<Applicant> list = new List<Applicant>();
            using SqlConnection con = new SqlConnection(connection);
            con.Open();

            string query = "select * from Applicants";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Applicant app = new Applicant();
                app.ApplicantId = reader.GetInt32(0);
                app.FirstName = reader.GetString(1);
                app.LastName = reader.GetString(2);
                app.Email = reader.GetString(3);
                app.Phone = reader.GetString(4);
                app.Resume = reader.GetString(5);
                
                list.Add(app);
            }
            return list;
        }
        //get the applications
        public List<JobApplication> GetApplicationsForJob(int JobId)
        {
            List<JobApplication> list = new List<JobApplication>();
            using SqlConnection con = new SqlConnection(connection);
            con.Open();

            string query = "select * from Applications where JobId=@jobid";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@jobid",JobId);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                JobApplication app = new JobApplication();
                app.ApplicantId = reader.GetInt32(0);
                app.JobId = reader.GetInt32(1);
                app.ApplicantId = reader.GetInt32(2);
                app.ApplicationDate = reader.GetDateTime(3);
                app.CoverLetter = reader.GetString(4);
               

                list.Add(app);
            }
            return list;
        }
        //calcualte the avg salary

        public void CalculateAverageSalary()
        {
            try
            {

                var jobs = GetJobListings();
                decimal total = 0;
                int count = 0;

                foreach (var job in jobs)
                {
                    if (job.Salary < 0)
                        throw new SalaryCalculation("Negative salary found in Job ID:" + job.JobId);

                    total += job.Salary;
                    count++;
                }

                if (count > 0)
                    Console.WriteLine("Average Salary: " + (total / count));
                else
                    Console.WriteLine("No jobs found.");
            }
            catch (SalaryCalculation ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

    }

    //main jobboard app class

class JobBoardApp
{
    static void Main()
    {
        string connection = "Server=.;Initial Catalog=CareerHub;Integrated Security=True;TrustServerCertificate=True;";

            SqlConnection con = new SqlConnection(connection);
            con.Open();
            Console.WriteLine("Connected to database");
            //DatabaseManager db= new DatabaseManager();
            //db.InitializeDatabase();

            while (true)
        {
            Console.WriteLine("\n--- CareerHub Menu ---");
            Console.WriteLine("1. View Job Listings");
            Console.WriteLine("2. Register Applicant");
            Console.WriteLine("3. Submit Job Application");
            Console.WriteLine("4. Post a Job");
            Console.WriteLine("5. Search Jobs by Salary");
            Console.WriteLine("6. Exit");
            Console.Write("Choose an option: ");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    ViewJobs(con);
                    break;
                case 2:
                    RegisterApplicant(con);
                    break;
                case 3:
                    SubmitApplication(con);
                    break;
                case 4:
                    PostJob(con);
                    break;
                case 5:
                    SalaryRangeFilter(con);
                    break;
                case 6:
                    con.Close();
                    Console.WriteLine("Disconnected from DB. ");
                    return;
                default:
                    Console.WriteLine("Invalid option. Try again.");
                    break;
            }
        }
    }

        //job listing retrieval

    static void ViewJobs(SqlConnection con)
    {
        Console.WriteLine("\n--- Job Listings ---");
        string q1 = "SELECT job_title, company_id, salary FROM Jobs";
        SqlCommand cmd1 = new SqlCommand(q1, con);
        SqlDataReader reader1 = cmd1.ExecuteReader();
        while (reader1.Read())
        {
            Console.WriteLine($"Title: {reader1.GetString(0)}, CompanyID: {reader1.GetInt32(1)}, Salary: ${reader1.GetDecimal(2)}");
        }
        reader1.Close();
    }

        //applicant profile creation
    static void RegisterApplicant(SqlConnection con)
    {
        try
        {
            Console.WriteLine("\n--- Applicant Registration ---");
            Console.Write("Applicant ID: ");
            int appId = int.Parse(Console.ReadLine());
            Console.Write("First Name: ");
            string fname = Console.ReadLine();
            Console.Write("Last Name: ");
            string lname = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            Console.Write("Phone: ");
            string phone = Console.ReadLine();
            Console.Write("Resume Filename: ");
            string resume = Console.ReadLine();

            string q2 = "INSERT INTO Applicants VALUES (@id, @fname, @lname, @mail, @phone, @res)";
            SqlCommand cmd2 = new SqlCommand(q2, con);
            cmd2.Parameters.AddWithValue("@id", appId);
            cmd2.Parameters.AddWithValue("@fname", fname);
            cmd2.Parameters.AddWithValue("@lname", lname);
            cmd2.Parameters.AddWithValue("@mail", email);
            cmd2.Parameters.AddWithValue("@phone", phone);
            cmd2.Parameters.AddWithValue("@res", resume);
            cmd2.ExecuteNonQuery();
            Console.WriteLine("Applicant registered.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error in registration: " + ex.Message);
        }
    }

        //job application submission
    static void SubmitApplication(SqlConnection con)
    {
        try
        {
            Console.WriteLine("\n--- Apply for Job ---");
            Console.Write("Application ID: ");
            int aid = int.Parse(Console.ReadLine());
            Console.Write("Job ID: ");
            int jid = int.Parse(Console.ReadLine());
            Console.Write("Applicant ID: ");
            int appid = int.Parse(Console.ReadLine());
            Console.Write("Cover Letter: ");
            string cover = Console.ReadLine();

            string q3 = "INSERT INTO Applications VALUES (@appid, @jobid, @applicantid, @date, @letter)";
            SqlCommand cmd3 = new SqlCommand(q3, con);
            cmd3.Parameters.AddWithValue("@appid", aid);
            cmd3.Parameters.AddWithValue("@jobid", jid);
            cmd3.Parameters.AddWithValue("@applicantid", appid);
            cmd3.Parameters.AddWithValue("@date", DateTime.Now);
            cmd3.Parameters.AddWithValue("@letter", cover);
            cmd3.ExecuteNonQuery();
            Console.WriteLine("Application submitted.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error in application: " + ex.Message);
        }
    }

        //company job posting
    static void PostJob(SqlConnection con)
    {
        try
        {
            Console.WriteLine("\n--- Post a Job ---");
            Console.Write("Job ID: ");
            int jobId = int.Parse(Console.ReadLine());
            Console.Write("Company ID: ");
            int cid = int.Parse(Console.ReadLine());
            Console.Write("Job Title: ");
            string title = Console.ReadLine();
            Console.Write("Description: ");
            string desc = Console.ReadLine();
            Console.Write("Location: ");
            string loc = Console.ReadLine();
            Console.Write("Salary: ");
            decimal sal = decimal.Parse(Console.ReadLine());
            Console.Write("Job Type: ");
            string type = Console.ReadLine();

            string q4 = "INSERT INTO Jobs VALUES (@id, @cid, @title, @desc, @loc, @sal, @type, @date)";
            SqlCommand cmd4 = new SqlCommand(q4, con);
            cmd4.Parameters.AddWithValue("@id", jobId);
            cmd4.Parameters.AddWithValue("@cid", cid);
            cmd4.Parameters.AddWithValue("@title", title);
            cmd4.Parameters.AddWithValue("@desc", desc);
            cmd4.Parameters.AddWithValue("@loc", loc);
            cmd4.Parameters.AddWithValue("@sal", sal);
            cmd4.Parameters.AddWithValue("@type", type);
            cmd4.Parameters.AddWithValue("@date", DateTime.Now);
            cmd4.ExecuteNonQuery();
            Console.WriteLine("Job posted successfully.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error in posting job: " + ex.Message);
        }
    }

        //salary range query
    static void SalaryRangeFilter(SqlConnection con)
    {
        Console.WriteLine("\n--- Salary Range Filter ---");
        Console.Write("Enter min salary: ");
        decimal min = decimal.Parse(Console.ReadLine());
        Console.Write("Enter max salary: ");
        decimal max = decimal.Parse(Console.ReadLine());

        string q5 = "SELECT job_title, salary FROM Jobs WHERE salary BETWEEN @min AND @max";
        SqlCommand cmd5 = new SqlCommand(q5, con);
        cmd5.Parameters.AddWithValue("@min", min);
        cmd5.Parameters.AddWithValue("@max", max);
        SqlDataReader reader2 = cmd5.ExecuteReader();
            bool found = false;
        while (reader2.Read())
        {
            Console.WriteLine($"Title: {reader2.GetString(0)}, Salary: ${reader2.GetDecimal(1)}");
                found=true;
        }
            if (!found)
            {
                Console.WriteLine("No jobs found within this range.");
            }
        reader2.Close();
    }
}


}